<footer>
	<p id="login-copyright">&copy; <a href="http://www.thomasmore.be/">Thomas More</a> | Ontwikkeld door <a href="http://designosource.be/">Designosource</a> - Studenten van  <a href="http://weareimd.be/">Interactive Multimedia Design</a></p>
</footer>