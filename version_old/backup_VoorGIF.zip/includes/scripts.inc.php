<script src="js/jquery-1.11.1.min.js" type="text/javascript"></script>
<script src="js/jquery-ui.min.js" type="text/javascript"></script>

<script src="js/modernizr2.8.3.js" type="text/javascript"></script>

<!--[if lt IE 9]>
	<script src="js/excanvas.min.js" type="text/javascript"></script>
<![endif]-->
<!--[if (gte IE 6)&(lte IE 8)]>
 	<script type="text/javascript" src="js/selectivizr-min.js"></script>
<![endif]-->

<script type="text/javascript" src="js/jquery.flippy.min.js"></script>

<script src="js/hammer.min.js" type="text/javascript"></script>
<script src="js/jquery.hammer.js" type="text/javascript"></script>

<script src="js/script.js" type="text/javascript"></script>