<?php 
	header("location: ".$_SERVER["REDIRECT_Shib_logoutURL"]);
 ?>